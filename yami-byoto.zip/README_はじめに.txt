ACCESIBLE HORROR ENTERTAINMENT — 闇病棟 無料配布パック

収録内容
- yami-byoto-fixed.html

遊び方
1. ZIPファイルを展開してください。
2. yami-byoto-fixed.html をChromeまたはEdgeで開いてください。
3. 3D描画にThree.jsを使用するため、起動時にインターネット接続が必要です。

このパックは無料配布です。ファイルの改変・再配布の条件は、配布元の案内に従ってください。
