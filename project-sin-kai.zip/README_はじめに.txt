ACCESIBLE HORROR ENTERTAINMENT — project sin-kai 無料配布パック

収録内容
- sin-kai_ch1.html ～ sin-kai_ch7(3).html（Chapter 1～7）
- sin-kai_addch_exhibits_映像表示修正版(1).html（展示・Add Chapter）

遊び方
1. ZIPファイルを展開してください。
2. 遊びたいHTMLファイルをChromeまたはEdgeで開いてください。
3. 描画・演出にThree.js等の外部ライブラリを使う章があります。初回起動時や外部ライブラリ読み込み時はインターネット接続が必要です。

このパックは無料配布です。ファイルの改変・再配布の条件は、配布元の案内に従ってください。
